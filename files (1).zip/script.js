// ===== NAVBAR SCROLL =====
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 60);
});

// ===== MOBILE MENU =====
document.getElementById('hamburger').addEventListener('click', () =>
  document.getElementById('mobileMenu').classList.add('open')
);
document.getElementById('closeMenu').addEventListener('click', () =>
  document.getElementById('mobileMenu').classList.remove('open')
);
function closeMobile() {
  document.getElementById('mobileMenu').classList.remove('open');
}

// ===== MENU FILTER =====
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const cat = tab.dataset.cat;
    document.querySelectorAll('.dish-card').forEach(card => {
      card.classList.toggle('hidden', cat !== 'all' && card.dataset.cat !== cat);
    });
  });
});

// ===== RESERVATION FORM =====
function submitReservation(e) {
  e.preventDefault();
  document.getElementById('resForm').style.display = 'none';
  document.getElementById('resSuccess').classList.add('show');
}

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
  });
});

// ===== SCROLL REVEAL =====
const io = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      io.unobserve(entry.target);
    }
  });
}, { threshold: 0.08 });

document.querySelectorAll('.dish-card, .contact-card, .stat-item, .res-form-box, .about-wrap').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(18px)';
  el.style.transition = 'opacity 0.55s ease, transform 0.55s ease';
  io.observe(el);
});

// ===== MIN DATE =====
const d = document.querySelector('input[type="date"]');
if (d) d.setAttribute('min', new Date().toISOString().split('T')[0]);
